package com.cognizant.account.exception;

public class NotFoundException extends Exception {
	public NotFoundException(String msg) {
		super(msg);
	}
}
