insert into users values('ABC001','ABC001');
insert into users values('ABC002','ABC002');
insert into users values('ABC003','ABC003');
insert into users values('ABC004','ABC004');
insert into users values('ABC005','ABC005');
insert into users values('ABC006','ABC006');
insert into users values('ABC007','ABC007');