export interface User{
    accountNo: string;
    password: string;
}